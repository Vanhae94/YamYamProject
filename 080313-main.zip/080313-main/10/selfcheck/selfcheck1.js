function getCircleArea(radius){
  return radius * radius * 3.14;
}
const area = getCircleArea(10);
console.log(`원의 넓이: ${area}`);