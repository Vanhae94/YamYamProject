function gugudan(){ // 함수 시작
  for(let i = 1; i <= 9; i++){
    console.log(`3 * ${i} = ${3 * i}`);
  }  
} // 함수 끝
gugudan(); // gugudan 함수 호출
