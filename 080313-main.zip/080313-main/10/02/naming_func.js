const gugudan = function gugudan(){
  for(let i = 1; i <= 9; i++){
    console.log(`3 * ${i} = ${3 * i}`);
  }  
};
gugudan(); // 함수 호출
