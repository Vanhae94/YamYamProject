function sum(a = 10, b = 10){
  console.log(a, b);
}
sum(); // 10, 10