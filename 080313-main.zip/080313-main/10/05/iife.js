(function init(){
  console.log("initialized!");
})();
// init();