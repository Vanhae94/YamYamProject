let num = 10;
if(num % 2 === 0){
  console.log("변수 num에 할당된 숫자는 짝수입니다.");
}
