let num = 5;
if(num % 2 === 0){
  console.log("변수 num에 할당된 숫자는 짝수입니다.");
}else{
  console.log("변수 num에 할당된 숫자는 홀수입니다.");
}
