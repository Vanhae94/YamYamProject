for(let dan = 1; dan <= 9; dan++){
  for(let num = 1; num <= 9; num++){
    console.log(`${dan} * ${num} = ${dan * num}`);
  }
}