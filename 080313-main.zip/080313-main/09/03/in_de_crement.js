let increment = 10; 
increment++; 
let decrement = 10;
decrement--; 
console.log(increment); // 11
console.log(decrement); // 9
