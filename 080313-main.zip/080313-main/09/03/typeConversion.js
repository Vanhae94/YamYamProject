let result = 10 + "10";
console.log(result); // 1010
