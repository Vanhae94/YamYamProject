let sum = 10 + 20 * 3;
//소괄호 적용
//let sum = (10 + 20) * 3;
console.log(sum);
