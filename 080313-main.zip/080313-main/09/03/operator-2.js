let num = 10;
let result = num *= 3;
console.log(result); // 30