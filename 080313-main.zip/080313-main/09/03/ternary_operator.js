let score = 90; 
let grade = score >= 90 ? 'A+' : 'B'; 
console.log(grade); // A+
