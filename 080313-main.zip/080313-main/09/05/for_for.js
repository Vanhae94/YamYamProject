for(let i = 0; i < 2; i++){
  console.log(`i: ${i}`);
  for(let k = 0; k < 2; k++){
    console.log(`k: ${k}`);
  }
}
