let studentScore = [80, 70, 90, 60]; // 국어, 영어, 수학, 과학 점수 
console.log(studentScore[1]); // 70, 1번 인덱스의 데이터에 접근
