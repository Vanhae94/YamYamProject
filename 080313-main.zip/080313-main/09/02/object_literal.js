let studentScore = {
  koreanScore:80,
  englishScore:70,
  mathScore:90,
  scienceScore:60
};
console.log(studentScore.koreanScore); // 80
console.log(studentScore['englishScore']); // 70
