let num1 = 10;
let num2 = 0.1;
console.log(num1);
console.log(num2);
