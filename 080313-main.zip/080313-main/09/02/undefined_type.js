let empty; 
console.log(empty); // undefined
