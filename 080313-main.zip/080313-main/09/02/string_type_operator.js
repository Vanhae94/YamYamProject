let string = '문자열' + " 연결 연산자";
console.log(string);
  