let sum = 0.1 + 0.2;
console.log(sum);
