const random = Math.random();
console.log(random); // 실행할 때마다 달라짐
