const email = "test!naver.com";
if(email.indexOf("@") === -1){
  console.log("올바른 이메일 형식이 아닙니다.");
}
