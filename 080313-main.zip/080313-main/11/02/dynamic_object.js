const person = {};
person.name = {
  firstName:"GilDong",
  lastName:"Hong"
};
person.likes = ["apple", "samsung"];
person.printHello = function(){
  return "hello";
}
console.log(person);